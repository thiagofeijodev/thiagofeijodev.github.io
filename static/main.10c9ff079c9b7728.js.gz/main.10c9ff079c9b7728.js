(()=>{"use strict";var e,r,t,a,i={9272(e,r,t){t.d(r,{A:()=>l});var a=t(801),i=t.n(a),o=t(3370),n=t.n(o)()(i());n.push([e.id,`body {
  margin: 0px;
  font-family: "Lato", sans-serif;
}

.Fp5dVdo_Ea4NX9pc {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  background-color: #212121;
  width: 100dvw;
  height: 100dvh;
}

.SF60r9nm8I1ExOs7 {
  width: 13rem;
  height: 13rem;
  border-radius: 50%;
  animation: ZOuEkkbRRJMIDYBH 0.8s ease-out forwards;
  opacity: 0;
}

.R9muPSFXIUp08C35 {
  margin-top: 2rem;
  margin-bottom: 0.5rem;
  font-size: 2rem;
  line-height: 2rem;
  color: #dadada;
  animation: ZOuEkkbRRJMIDYBH 0.8s ease-out 0.2s forwards;
  opacity: 0;
}

.L96_KQXoTRYeRwBC {
  margin-top: 0.1rem;
  margin-bottom: 0.5rem;
  font-size: 1.5rem;
  color: #dadada;
  line-height: 2rem;
  animation: ZOuEkkbRRJMIDYBH 0.8s ease-out 0.4s forwards;
  opacity: 0;
}

.zGlWtsxzaciHVZ9u {
  list-style: none;
  padding: 0;
  animation: ZOuEkkbRRJMIDYBH 0.8s ease-out 0.6s forwards;
  opacity: 0;
}

@keyframes ZOuEkkbRRJMIDYBH {
  from {
    opacity: 0;
    transform: translateY(20px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.fa_Pkj5yOMgC9ELh {
  display: inline-block;
  position: relative;
  margin: 0px 10px;
}

.fa_Pkj5yOMgC9ELh svg {
  color: white;
  fill: white;
  width: 32px;
  height: 32px;
}

.fa_Pkj5yOMgC9ELh svg:hover {
  filter: drop-shadow(2px 2px 10px gray);
}

.pIAfYdZrHwNTrk70 {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 2rem;
  width: 100%;
}

.W1lxH3z0fOMDpQ5N {
  font-size: 1.5rem;
  color: #dadada;
  margin-bottom: 1rem;
}

.nOB7hsdCBQsu5YMT {
  display: flex;
  gap: 1.5rem;
  flex-wrap: wrap;
  justify-content: center;
}

.p8sEKOByhu07jAr3 {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 12px;
  padding: 1.5rem;
  width: 200px;
  text-decoration: none;
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  backdrop-filter: blur(10px);
}

.p8sEKOByhu07jAr3:hover {
  transform: translateY(-5px);
  background: rgba(255, 255, 255, 0.1);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
  border-color: rgba(255, 255, 255, 0.2);
}

.YQGNRIFiMUYso27E {
  color: #fff;
  font-size: 1.1rem;
  font-weight: 600;
  text-align: center;
  margin: 0;
}
`,""]),n.locals={content:"Fp5dVdo_Ea4NX9pc",avatar:"SF60r9nm8I1ExOs7",fadeInUp:"ZOuEkkbRRJMIDYBH",name:"R9muPSFXIUp08C35",role:"L96_KQXoTRYeRwBC",ul:"zGlWtsxzaciHVZ9u",li:"fa_Pkj5yOMgC9ELh",projectsContainer:"pIAfYdZrHwNTrk70",projectsTitle:"W1lxH3z0fOMDpQ5N",projectList:"nOB7hsdCBQsu5YMT",projectCard:"p8sEKOByhu07jAr3",projectCardTitle:"YQGNRIFiMUYso27E"};let l=n},4499(e,r,t){var a=t(3712),i=t(538);t(4114);let o=e=>{let{alt:r}=e;return(0,a.jsx)("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg","aria-label":r,children:(0,a.jsx)("path",{d:"M10.9 2.1c-4.6.5-8.3 4.2-8.8 8.7-.5 4.7 2.2 8.9 6.3 10.5.3.1.6-.1.6-.5v-1.6s-.4.1-.9.1c-1.4 0-2-1.2-2.1-1.9-.1-.4-.3-.7-.6-1-.3-.1-.4-.1-.4-.2 0-.2.3-.2.4-.2.6 0 1.1.7 1.3 1 .5.8 1.1 1 1.4 1 .4 0 .7-.1.9-.2.1-.7.4-1.4 1-1.8-2.3-.5-4-1.8-4-4 0-1.1.5-2.2 1.2-3-.1-.2-.2-.7-.2-1.4 0-.4 0-1 .3-1.6 0 0 1.4 0 2.8 1.3.5-.2 1.2-.3 1.9-.3s1.4.1 2 .3C15.3 6 16.8 6 16.8 6c.2.6.2 1.2.2 1.6 0 .8-.1 1.2-.2 1.4.7.8 1.2 1.8 1.2 3 0 2.2-1.7 3.5-4 4 .6.5 1 1.4 1 2.3v2.6c0 .3.3.6.7.5 3.7-1.5 6.3-5.1 6.3-9.3 0-6-5.1-10.7-11.1-10z",fill:"#ffffff"})})},n=e=>{let{alt:r}=e;return(0,a.jsx)("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg","aria-label":r,children:(0,a.jsx)("path",{d:"M21 3H3v18h18V3zM9 17H6.477v-7H9v7zM7.694 8.717c-.771 0-1.286-.514-1.286-1.2s.514-1.2 1.371-1.2c.771 0 1.286.514 1.286 1.2s-.514 1.2-1.371 1.2zM18 17h-2.442v-3.826c0-1.058-.651-1.302-.895-1.302s-1.058.163-1.058 1.302V17h-2.523v-7h2.523v.977c.325-.57.976-.977 2.197-.977S18 10.977 18 13.174V17z",fill:"#ffffff"})})};var l=t(5072),s=t.n(l),d=t(7825),c=t.n(d),h=t(7659),p=t.n(h),f=t(5056),u=t.n(f),g=t(540),m=t.n(g),v=t(1113),w=t.n(v),x=t(9272),j={};j.styleTagTransform=w(),j.setAttributes=u(),j.insert=p().bind(null,"head"),j.domAPI=c(),j.insertStyleElement=m(),s()(x.A,j);let b=x.A&&x.A.locals?x.A.locals:void 0,k=document.getElementById("root");(0,i.createRoot)(k).render((0,a.jsx)(()=>(0,a.jsxs)("div",{className:null==b?void 0:b.content,children:[(0,a.jsx)("img",{className:null==b?void 0:b.avatar,src:"https://avatars.githubusercontent.com/u/17260775",alt:"avatar"}),(0,a.jsx)("h1",{className:null==b?void 0:b.name,children:"Thiago Feij\xf3"}),(0,a.jsx)("h2",{className:null==b?void 0:b.role,children:"Software Developer"}),(0,a.jsxs)("ul",{className:null==b?void 0:b.ul,children:[(0,a.jsx)("li",{className:null==b?void 0:b.li,children:(0,a.jsx)("a",{href:"https://github.com/thiagofeijodev/",target:"_blank","aria-label":"Github",rel:"noreferrer",children:(0,a.jsx)(o,{alt:"Github link"})})}),(0,a.jsx)("li",{className:null==b?void 0:b.li,children:(0,a.jsx)("a",{href:"https://www.linkedin.com/in/thiagofeijodev/",target:"_blank","aria-label":"LinkedIn",rel:"noreferrer",children:(0,a.jsx)(n,{alt:"Linkedin link"})})})]}),(0,a.jsxs)("div",{className:null==b?void 0:b.projectsContainer,children:[(0,a.jsx)("h3",{className:null==b?void 0:b.projectsTitle,children:"Projects"}),(0,a.jsxs)("div",{className:null==b?void 0:b.projectList,children:[(0,a.jsx)("a",{href:"/pdf-password-remover/",className:null==b?void 0:b.projectCard,target:"_blank",rel:"noopener noreferrer",children:(0,a.jsx)("h4",{className:null==b?void 0:b.projectCardTitle,children:"PDF Password Remover"})}),(0,a.jsx)("a",{href:"/countdown/",className:null==b?void 0:b.projectCard,target:"_blank",rel:"noopener noreferrer",children:(0,a.jsx)("h4",{className:null==b?void 0:b.projectCardTitle,children:"Countdown Timer"})})]})]})]}),{})),"serviceWorker"in navigator&&navigator.serviceWorker.register("service-worker.js");let y="G-QVT4BW387B";if(y){let e=document.createElement("script");e.async=!0,e.src=`https://www.googletagmanager.com/gtag/js?id=${y}`,document.head.appendChild(e),window.dataLayer=window.dataLayer||[],window.gtag=window.gtag||function(){window.dataLayer.push(arguments)},window.gtag("js",new Date),window.gtag("config",y)}}},o={};function n(e){var r=o[e];if(void 0!==r)return r.exports;var t=o[e]={id:e,exports:{}};return i[e].call(t.exports,t,t.exports,n),t.exports}n.m=i,n.n=e=>{var r=e&&e.__esModule?()=>e.default:()=>e;return n.d(r,{a:r}),r},n.d=(e,r)=>{for(var t in r)n.o(r,t)&&!n.o(e,t)&&Object.defineProperty(e,t,{enumerable:!0,get:r[t]})},n.g=(()=>{if("object"==typeof globalThis)return globalThis;try{return this||Function("return this")()}catch(e){if("object"==typeof window)return window}})(),n.o=(e,r)=>Object.prototype.hasOwnProperty.call(e,r),n.nc=void 0,e=[],n.O=(r,t,a,i)=>{if(t){i=i||0;for(var o=e.length;o>0&&e[o-1][2]>i;o--)e[o]=e[o-1];e[o]=[t,a,i];return}for(var l=1/0,o=0;o<e.length;o++){for(var[t,a,i]=e[o],s=!0,d=0;d<t.length;d++)(!1&i||l>=i)&&Object.keys(n.O).every(e=>n.O[e](t[d]))?t.splice(d--,1):(s=!1,i<l&&(l=i));if(s){e.splice(o--,1);var c=a();void 0!==c&&(r=c)}}return r},n.rv=()=>"1.6.6",r={889:0},n.O.j=e=>0===r[e],t=(e,t)=>{var a,i,[o,l,s]=t,d=0;if(o.some(e=>0!==r[e])){for(a in l)n.o(l,a)&&(n.m[a]=l[a]);if(s)var c=s(n)}for(e&&e(t);d<o.length;d++)i=o[d],n.o(r,i)&&r[i]&&r[i][0](),r[i]=0;return n.O(c)},(a=self.webpackChunkthiagofeijodev_github_io=self.webpackChunkthiagofeijodev_github_io||[]).forEach(t.bind(null,0)),a.push=t.bind(null,a.push.bind(a)),n.ruid="bundler=rspack@1.6.6";var l=n.O(void 0,["72"],()=>n(4499));l=n.O(l)})();